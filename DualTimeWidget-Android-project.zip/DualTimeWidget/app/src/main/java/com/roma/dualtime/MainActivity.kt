package com.roma.dualtime

import android.app.Activity
import android.os.Bundle
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val text = TextView(this).apply {
            text = "Додай віджет «Подвійний час» на головний екран.\n\nВін показує 12- та 24-годинний формат одночасно."
            textSize = 18f
            setPadding(32, 48, 32, 32)
        }
        setContentView(text)
    }
}
