package com.roma.dualtime

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DualTimeWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        updateAll(context)
        scheduleMinuteUpdates(context)
    }

    override fun onEnabled(context: Context) {
        scheduleMinuteUpdates(context)
    }

    override fun onDisabled(context: Context) {
        val intent = Intent(context, DualTimeWidgetProvider::class.java).setAction(ACTION_UPDATE)
        val pending = PendingIntent.getBroadcast(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_UPDATE, Intent.ACTION_TIME_CHANGED, Intent.ACTION_TIMEZONE_CHANGED -> updateAll(context)
            Intent.ACTION_BOOT_COMPLETED -> {
                updateAll(context)
                scheduleMinuteUpdates(context)
            }
        }
    }

    companion object {
        private const val ACTION_UPDATE = "com.roma.dualtime.ACTION_UPDATE"

        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val component = ComponentName(context, DualTimeWidgetProvider::class.java)
            val ids = manager.getAppWidgetIds(component)
            if (ids.isEmpty()) return

            val now = Date()
            val twelveHour = SimpleDateFormat("hh:mm", Locale.getDefault()).format(now)
            val twentyFourHour = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            val views = RemoteViews(context.packageName, R.layout.dual_time_widget).apply {
                setTextViewText(R.id.time_12, twelveHour)
                setTextViewText(R.id.time_24, twentyFourHour)
            }
            manager.updateAppWidget(ids, views)
        }

        private fun scheduleMinuteUpdates(context: Context) {
            val intent = Intent(context, DualTimeWidgetProvider::class.java).setAction(ACTION_UPDATE)
            val pending = PendingIntent.getBroadcast(
                context, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarm.setInexactRepeating(
                AlarmManager.RTC,
                System.currentTimeMillis() + 60_000L,
                60_000L,
                pending
            )
        }
    }
}
